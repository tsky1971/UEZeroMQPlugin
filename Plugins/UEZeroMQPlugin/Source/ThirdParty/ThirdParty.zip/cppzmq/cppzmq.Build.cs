// Fill out your copyright notice in the Description page of Project Settings.

using System.IO;
using UnrealBuildTool;

public class cppzmq : ModuleRules
{
	public cppzmq(ReadOnlyTargetRules Target)
	{
		Type = ModuleType.External;
		
        PublicIncludePaths.AddRange(new string[] { ModuleDirectory });

        if (Target.Platform == UnrealTargetPlatform.Win64)
		{
            // Add the import library
            
		}
        else if (Target.Platform == UnrealTargetPlatform.Mac)
        {
            
        }
	}
}
